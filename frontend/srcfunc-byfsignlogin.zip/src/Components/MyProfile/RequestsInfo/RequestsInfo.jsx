
import SectionHeader from '../SectionHeader';


const RequestsInfo = ({ img, title, star, reviews, prevPrice, newPrice }) => {
    return (
        <>
            <SectionHeader 
                title="MIS PEDIDOS" 
                buttonText={"Consultar"} 
                onClick={""} 
            />
        </>
    );
};
    
export default RequestsInfo;